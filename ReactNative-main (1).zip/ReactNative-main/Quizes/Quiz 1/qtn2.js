console.log(1 + '2' + '2')
// OUTPUT:
// 122

console.log(1 + + '2' + '2')
// OUTPUT:
// 32

console.log(1 + -'1' + '2')
// OUTPUT:
// 02

console.log('A' - 'B' + '2')
// OUTPUT:
// NaN2

console.log('A' - 'B' + '2')
// OUTPUT:
// NaN2

