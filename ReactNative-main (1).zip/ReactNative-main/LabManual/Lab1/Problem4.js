/*Problem 4:
Write a JavaScript that calculates the squares and cubes of the numbers from 0 to 10.
*/
for (let i = 0; i <= 10; i++){
    square = i * i;
    cube = i * i * i;
    console.log("Square of " + i + " is " + square)
    console.log("Cube of " + i + " is " + cube )
}