/*Problem 3:
Write program to find sum of even digits. Input 23617 output 2+6=8.
(Hint: Convert string to array and use map function)
*/

