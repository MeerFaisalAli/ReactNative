/*Problem 1:
Write program to print the kth digit from last. E.g. input 23617 and k=4 output 3. */